package app.onlyplay.ui.player.controls

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.onlyplay.preferences.PlayerButton
import app.onlyplay.ui.player.Panels
import app.onlyplay.ui.player.PlayerActivity
import app.onlyplay.ui.player.PlayerViewModel
import app.onlyplay.ui.player.Sheets
import app.onlyplay.ui.player.VideoAspect
import app.onlyplay.ui.player.controls.components.ControlsButton
import app.onlyplay.ui.player.controls.components.ControlsGroup
import app.onlyplay.ui.theme.controlColor
import app.onlyplay.ui.theme.spacing
import dev.vivvvek.seeker.Segment

@Composable
fun TopPlayerControlsPortrait(
  mediaTitle: String?,
  hideBackground: Boolean,
  onBackPress: () -> Unit,
  onOpenSheet: (Sheets) -> Unit,
  viewModel: PlayerViewModel,
) {
  val playlistModeEnabled = viewModel.hasPlaylistSupport()
  val clickEvent = LocalPlayerButtonsClickEvent.current

  Column {
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      ControlsGroup {
        ControlsButton(
          icon = Icons.AutoMirrored.Default.ArrowBack,
          onClick = onBackPress,
          color = if (hideBackground) controlColor else MaterialTheme.colorScheme.onSurface,
        )

        val titleInteractionSource = remember { androidx.compose.foundation.interaction.MutableInteractionSource() }

        androidx.compose.foundation.layout.Box(
          modifier =
            Modifier
              .clip(RoundedCornerShape(50))
              .clickable(
                enabled = playlistModeEnabled,
                onClick = {
                  clickEvent()
                  onOpenSheet(Sheets.Playlist)
                },
              ),
        ) {
          Surface(
            shape = RoundedCornerShape(50),
            color =
              if (hideBackground) {
                Color.Transparent
              } else {
                MaterialTheme.colorScheme.surfaceContainer.copy(
                  alpha = 0.55f,
                )
              },
            contentColor = if (hideBackground) controlColor else MaterialTheme.colorScheme.onSurface,
            tonalElevation = 0.dp,
            shadowElevation = 0.dp,
            border =
              if (hideBackground) {
                null
              } else {
                BorderStroke(
                  1.dp,
                  MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f),
                )
              },
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(MaterialTheme.spacing.extraSmall),
              modifier =
                Modifier.padding(
                  horizontal = MaterialTheme.spacing.medium,
                  vertical = MaterialTheme.spacing.small,
                ),
            ) {
              viewModel.getPlaylistInfo()?.let { playlistInfo ->
                Text(
                  text = playlistInfo,
                  textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                  style = MaterialTheme.typography.bodyMedium,
                  maxLines = 1,
                  overflow = TextOverflow.Visible,
                  fontFamily = FontFamily.Monospace,
                  color = MaterialTheme.colorScheme.primary,
                )
                Text(
                  text = Typography.bullet.toString(),
                  textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                  style = MaterialTheme.typography.bodyMedium,
                  maxLines = 1,
                  color = if (hideBackground) controlColor else MaterialTheme.colorScheme.onSurface,
                  overflow = TextOverflow.Clip,
                )
              }
              Text(
                text = mediaTitle ?: "",
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodyMedium,
                fontFamily = FontFamily.Monospace,
                color = if (hideBackground) controlColor else MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.weight(1f, fill = false),
              )
            }
          }
        }
      }
    }
  }
}

@Composable
fun BottomPlayerControlsPortrait(
  buttons: List<PlayerButton>,
  chapters: List<Segment>,
  currentChapter: Int?,
  isSpeedNonOne: Boolean,
  currentZoom: Float,
  aspect: VideoAspect,
  mediaTitle: String?,
  hideBackground: Boolean,
  decoder: app.onlyplay.ui.player.Decoder,
  playbackSpeed: Float,
  onBackPress: () -> Unit,
  onOpenSheet: (Sheets) -> Unit,
  onOpenPanel: (Panels) -> Unit,
  viewModel: PlayerViewModel,
  activity: PlayerActivity,
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(bottom = MaterialTheme.spacing.large)
      .horizontalScroll(rememberScrollState()),
    horizontalArrangement = Arrangement.Center,
    verticalAlignment = Alignment.CenterVertically,
  ) {
    ControlsGroup {
      buttons.forEach { button ->
        RenderPlayerButton(
          button = button,
          chapters = chapters,
          currentChapter = currentChapter,
          isPortrait = true,
          isSpeedNonOne = isSpeedNonOne,
          currentZoom = currentZoom,
          aspect = aspect,
          mediaTitle = mediaTitle,
          hideBackground = hideBackground,
          onBackPress = onBackPress,
          onOpenSheet = onOpenSheet,
          onOpenPanel = onOpenPanel,
          viewModel = viewModel,
          activity = activity,
          decoder = decoder,
          playbackSpeed = playbackSpeed,
          buttonSize = 48.dp,
        )
      }
    }
  }
}


/** Floating control bar: sits at the top of the player in both portrait and landscape. */
@Composable
fun FloatingPlayerControls(
  buttons: List<PlayerButton>,
  chapters: List<Segment>,
  currentChapter: Int?,
  isSpeedNonOne: Boolean,
  currentZoom: Float,
  aspect: VideoAspect,
  mediaTitle: String?,
  hideBackground: Boolean,
  decoder: app.onlyplay.ui.player.Decoder,
  playbackSpeed: Float,
  onBackPress: () -> Unit,
  onOpenSheet: (Sheets) -> Unit,
  onOpenPanel: (Panels) -> Unit,
  viewModel: PlayerViewModel,
  activity: PlayerActivity,
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .horizontalScroll(rememberScrollState()),
    horizontalArrangement = Arrangement.Center,
    verticalAlignment = Alignment.CenterVertically,
  ) {
    ControlsGroup {
      buttons.forEach { button ->
        RenderPlayerButton(
          button = button,
          chapters = chapters,
          currentChapter = currentChapter,
          isPortrait = true,
          isSpeedNonOne = isSpeedNonOne,
          currentZoom = currentZoom,
          aspect = aspect,
          mediaTitle = mediaTitle,
          hideBackground = hideBackground,
          onBackPress = onBackPress,
          onOpenSheet = onOpenSheet,
          onOpenPanel = onOpenPanel,
          viewModel = viewModel,
          activity = activity,
          decoder = decoder,
          playbackSpeed = playbackSpeed,
          buttonSize = 44.dp,
        )
      }
    }
  }
}
